# 🚀 دليل نشر نظام ERP
# ERP System Deployment Guide

---

## 📋 **المتطلبات الأساسية**

### **على جهازك المحلي:**
- ✅ Git (اختياري)
- ✅ SSH access إلى السيرفر
- ✅ `jq` لقراءة ملفات JSON
- ✅ `zip` لضغط الملفات

### **على السيرفر:**
- ✅ Ubuntu 20.04+ أو Debian 11+
- ✅ Root access أو sudo privileges
- ✅ اتصال بالإنترنت
- ✅ Domain name (اختياري للـ SSL)

---

## 🎯 **خطوات النشر**

### **1. تحضير الملفات**

```bash
# انسخ ملف البيئة النموذجي
cp .env.production.example .env.production

# عدّل الإعدادات حسب بيئتك
nano .env.production
```

**الإعدادات المهمة:**
- `SECRET_KEY`: مفتاح سري قوي (32 حرف على الأقل)
- `DATABASE_URL`: رابط قاعدة البيانات PostgreSQL
- `DOMAIN_NAME`: اسم النطاق الخاص بك
- `EMAIL_FOR_SSL`: بريدك الإلكتروني لـ Let's Encrypt

---

### **2. تعديل إعدادات النشر**

افتح ملف `deploy_erp_improved.sh` وعدّل:

```bash
nano deploy_erp_improved.sh
```

**عدّل هذه القيم في ملف `deploy_config.json`:**
```json
{
  "SERVER_HOST": "your-server.com",
  "SERVER_IP": "123.456.789.0",
  "SERVER_USER": "root",
  "NGINX_SERVER_NAME": "your-domain.com",
  "EMAIL_FOR_SSL": "your-email@example.com"
}
```

---

### **3. تشغيل سكريبت النشر**

```bash
# اجعل السكريبت قابل للتنفيذ
chmod +x deploy_erp_improved.sh

# شغّل السكريبت
./deploy_erp_improved.sh
```

**ماذا يفعل السكريبت:**
1. ✅ ينشئ ملف إعدادات
2. ✅ يضغط المشروع
3. ✅ يرفع الملفات للسيرفر
4. ✅ يثبت المتطلبات (Python, PostgreSQL, Nginx)
5. ✅ يعد قاعدة البيانات
6. ✅ ينشئ البيئة الافتراضية
7. ✅ يثبت المكتبات من requirements.txt
8. ✅ يعد خدمة systemd
9. ✅ يعد Nginx كـ reverse proxy
10. ✅ يفعّل HTTPS مع Let's Encrypt
11. ✅ يعد Health Check تلقائي
12. ✅ يعد النسخ الاحتياطي التلقائي

---

## 🔧 **الأوامر المفيدة بعد النشر**

### **إدارة التطبيق:**
```bash
# حالة التطبيق
systemctl status erp

# إعادة تشغيل التطبيق
systemctl restart erp

# إيقاف التطبيق
systemctl stop erp

# بدء التطبيق
systemctl start erp

# عرض السجلات
journalctl -u erp -f
```

### **إدارة Nginx:**
```bash
# حالة Nginx
systemctl status nginx

# إعادة تشغيل Nginx
systemctl restart nginx

# اختبار الإعدادات
nginx -t
```

### **إدارة قاعدة البيانات:**
```bash
# الدخول لقاعدة البيانات
sudo -u postgres psql erp_db

# عمل نسخة احتياطية يدوية
/usr/local/bin/erp_backup.sh

# عرض النسخ الاحتياطية
ls -lh /root/erp/backups/
```

---

## 📊 **معلومات النظام**

### **المسارات المهمة:**
- **المشروع:** `/root/erp`
- **البيئة الافتراضية:** `/root/erp/venv`
- **السجلات:** `/root/erp/logs`
- **النسخ الاحتياطية:** `/root/erp/backups`
- **الملفات المرفوعة:** `/root/erp/uploads`

### **الخدمات:**
- **التطبيق:** `erp.service`
- **Nginx:** `nginx.service`
- **PostgreSQL:** `postgresql.service`

### **المنافذ:**
- **Gunicorn:** 8000 (داخلي)
- **Nginx:** 80 (HTTP) و 443 (HTTPS)
- **PostgreSQL:** 5432 (داخلي)

---

## 🔒 **الأمان**

### **تغيير كلمة مرور المدير:**
1. سجّل دخول بـ: `admin` / `admin123`
2. اذهب إلى الإعدادات → تغيير كلمة المرور
3. غيّر كلمة المرور فوراً!

### **تأمين PostgreSQL:**
```bash
# تغيير كلمة مرور postgres
sudo -u postgres psql
\password postgres
```

### **جدار الحماية (Firewall):**
```bash
# تثبيت UFW
apt install ufw

# السماح بـ SSH
ufw allow 22/tcp

# السماح بـ HTTP/HTTPS
ufw allow 80/tcp
ufw allow 443/tcp

# تفعيل الجدار
ufw enable
```

---

## 🔄 **التحديثات**

### **تحديث التطبيق:**
```bash
cd /root/erp
source venv/bin/activate

# سحب التحديثات من Git (إذا كنت تستخدم Git)
git pull origin main

# تحديث المكتبات
pip install -r requirements.txt --upgrade

# إعادة تشغيل التطبيق
systemctl restart erp
```

---

## 🐛 **حل المشاكل**

### **التطبيق لا يعمل:**
```bash
# تحقق من السجلات
journalctl -u erp -n 50

# تحقق من حالة الخدمة
systemctl status erp

# أعد تشغيل الخدمة
systemctl restart erp
```

### **خطأ في قاعدة البيانات:**
```bash
# تحقق من حالة PostgreSQL
systemctl status postgresql

# تحقق من الاتصال
sudo -u postgres psql -c "SELECT version();"
```

### **مشكلة في Nginx:**
```bash
# اختبر الإعدادات
nginx -t

# عرض السجلات
tail -f /var/log/nginx/error.log
```

---

## 📞 **الدعم**

إذا واجهت أي مشاكل:
1. تحقق من السجلات: `/root/erp/logs/`
2. تحقق من `journalctl -u erp`
3. تحقق من `/var/log/nginx/error.log`

---

## ✅ **قائمة التحقق بعد النشر**

- [ ] التطبيق يعمل: `systemctl status erp`
- [ ] Nginx يعمل: `systemctl status nginx`
- [ ] HTTPS مفعّل: زيارة `https://your-domain.com`
- [ ] تسجيل الدخول يعمل
- [ ] تم تغيير كلمة مرور المدير
- [ ] النسخ الاحتياطي التلقائي يعمل
- [ ] Health Check يعمل

---

**🎉 مبروك! نظام ERP الخاص بك الآن يعمل على الإنتاج!**

