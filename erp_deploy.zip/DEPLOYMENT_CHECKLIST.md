# ✅ قائمة التحقق من النشر
# Deployment Checklist

---

## 📋 **قبل النشر (Pre-Deployment)**

### **1. الملفات المطلوبة:**
- [ ] `wsgi.py` موجود ويعمل ✅
- [ ] `requirements.txt` محدث (يحتوي على `psycopg2-binary`) ✅
- [ ] `.env.production.example` موجود ✅
- [ ] `deploy_erp_improved.sh` موجود ✅
- [ ] `DEPLOYMENT_GUIDE.md` موجود ✅

### **2. الإعدادات:**
- [ ] عدّلت `SERVER_IP` في السكريبت
- [ ] عدّلت `SERVER_HOST` في السكريبت
- [ ] عدّلت `NGINX_SERVER_NAME` (اسم النطاق)
- [ ] عدّلت `EMAIL_FOR_SSL` (بريدك الإلكتروني)
- [ ] نسخت `.env.production.example` إلى `.env.production`
- [ ] عدّلت `SECRET_KEY` في `.env.production`
- [ ] عدّلت `DATABASE_URL` في `.env.production`

### **3. الوصول للسيرفر:**
- [ ] لديك SSH access للسيرفر
- [ ] لديك root أو sudo privileges
- [ ] السيرفر يعمل Ubuntu 20.04+ أو Debian 11+

---

## 🚀 **أثناء النشر (During Deployment)**

### **1. تشغيل السكريبت:**
```bash
chmod +x deploy_erp_improved.sh
./deploy_erp_improved.sh
```

### **2. مراقبة التقدم:**
- [ ] تم إنشاء ملف الإعدادات
- [ ] تم ضغط المشروع
- [ ] تم رفع الملفات للسيرفر
- [ ] تم تحديث النظام
- [ ] تم تثبيت المتطلبات
- [ ] تم إعداد PostgreSQL
- [ ] تم إنشاء قاعدة البيانات
- [ ] تم فك ضغط المشروع
- [ ] تم إنشاء البيئة الافتراضية
- [ ] تم تثبيت المكتبات
- [ ] تم إنشاء خدمة systemd
- [ ] تم تشغيل التطبيق
- [ ] تم إعداد Nginx
- [ ] تم تفعيل HTTPS
- [ ] تم إعداد Health Check
- [ ] تم إعداد النسخ الاحتياطي

---

## ✅ **بعد النشر (Post-Deployment)**

### **1. التحقق من الخدمات:**
```bash
# تحقق من التطبيق
ssh root@YOUR_SERVER_IP "systemctl status erp"

# تحقق من Nginx
ssh root@YOUR_SERVER_IP "systemctl status nginx"

# تحقق من PostgreSQL
ssh root@YOUR_SERVER_IP "systemctl status postgresql"
```

- [ ] خدمة `erp` تعمل (active/running)
- [ ] خدمة `nginx` تعمل (active/running)
- [ ] خدمة `postgresql` تعمل (active/running)

### **2. التحقق من الموقع:**
- [ ] افتح `https://YOUR_DOMAIN` في المتصفح
- [ ] الموقع يفتح بدون أخطاء
- [ ] شهادة SSL صالحة (قفل أخضر)
- [ ] صفحة تسجيل الدخول تظهر

### **3. اختبار تسجيل الدخول:**
- [ ] سجّل دخول بـ: `admin` / `admin123`
- [ ] تسجيل الدخول نجح
- [ ] لوحة التحكم تظهر
- [ ] القوائم تعمل

### **4. الأمان:**
- [ ] غيّرت كلمة مرور المدير
- [ ] غيّرت كلمة مرور postgres
- [ ] فعّلت جدار الحماية (UFW)

### **5. النسخ الاحتياطي:**
```bash
# اختبر النسخ الاحتياطي اليدوي
ssh root@YOUR_SERVER_IP "/usr/local/bin/erp_backup.sh"

# تحقق من وجود الملف
ssh root@YOUR_SERVER_IP "ls -lh /root/erp/backups/"
```

- [ ] النسخ الاحتياطي اليدوي يعمل
- [ ] ملف النسخة الاحتياطية موجود
- [ ] Cron job للنسخ الاحتياطي مضاف

### **6. Health Check:**
```bash
# تحقق من Health Check
ssh root@YOUR_SERVER_IP "cat /usr/local/bin/erp_health_check.sh"

# تحقق من Cron
ssh root@YOUR_SERVER_IP "crontab -l | grep health_check"
```

- [ ] سكريبت Health Check موجود
- [ ] Cron job للـ Health Check مضاف

---

## 🧪 **اختبار الوظائف (Functional Testing)**

### **1. اختبار الشركات المتعددة:**
- [ ] افتح صفحة التسجيل: `https://YOUR_DOMAIN/auth/register`
- [ ] سجّل شركة جديدة
- [ ] تم إنشاء الشركة بنجاح
- [ ] تم تسجيل الدخول تلقائياً
- [ ] رمز الشركة ظهر (COMP002, COMP003, ...)

### **2. اختبار المخزون:**
- [ ] أضف منتج جديد
- [ ] أضف مخزون
- [ ] عرض المخزون

### **3. اختبار المبيعات:**
- [ ] أضف عميل
- [ ] أضف فاتورة مبيعات
- [ ] تحقق من تحديث المخزون
- [ ] تحقق من تحديث رصيد البنك

### **4. اختبار المشتريات:**
- [ ] أضف مورد
- [ ] أضف فاتورة مشتريات
- [ ] تحقق من تحديث المخزون
- [ ] تحقق من تحديث رصيد البنك

### **5. اختبار المحاسبة:**
- [ ] عرض دليل الحسابات
- [ ] أضف حساب بنكي
- [ ] أضف قيد محاسبي
- [ ] عرض التقارير المالية

---

## 📊 **مراقبة الأداء (Performance Monitoring)**

### **1. السجلات:**
```bash
# سجلات التطبيق
ssh root@YOUR_SERVER_IP "tail -f /root/erp/logs/erp.log"

# سجلات systemd
ssh root@YOUR_SERVER_IP "journalctl -u erp -f"

# سجلات Nginx
ssh root@YOUR_SERVER_IP "tail -f /var/log/nginx/access.log"
ssh root@YOUR_SERVER_IP "tail -f /var/log/nginx/error.log"
```

- [ ] لا توجد أخطاء في السجلات
- [ ] الطلبات تُسجل بشكل صحيح

### **2. استخدام الموارد:**
```bash
# استخدام CPU والذاكرة
ssh root@YOUR_SERVER_IP "top -bn1 | head -20"

# مساحة القرص
ssh root@YOUR_SERVER_IP "df -h"

# حالة PostgreSQL
ssh root@YOUR_SERVER_IP "sudo -u postgres psql -c 'SELECT * FROM pg_stat_activity;'"
```

- [ ] استخدام CPU معقول (< 80%)
- [ ] استخدام الذاكرة معقول (< 80%)
- [ ] مساحة القرص كافية (> 20% متاحة)

---

## 🔄 **الصيانة الدورية (Maintenance)**

### **يومياً:**
- [ ] تحقق من السجلات
- [ ] تحقق من النسخ الاحتياطية

### **أسبوعياً:**
- [ ] تحقق من استخدام الموارد
- [ ] تحقق من مساحة القرص
- [ ] راجع السجلات للأخطاء

### **شهرياً:**
- [ ] حدّث النظام: `apt update && apt upgrade`
- [ ] حدّث المكتبات: `pip install -r requirements.txt --upgrade`
- [ ] راجع النسخ الاحتياطية القديمة

---

## 🆘 **في حالة الطوارئ**

### **التطبيق لا يعمل:**
```bash
systemctl restart erp
journalctl -u erp -n 100
```

### **قاعدة البيانات لا تعمل:**
```bash
systemctl restart postgresql
sudo -u postgres psql -c "SELECT version();"
```

### **استعادة من نسخة احتياطية:**
```bash
# إيقاف التطبيق
systemctl stop erp

# استعادة قاعدة البيانات
gunzip -c /root/erp/backups/backup_YYYYMMDD_HHMMSS.sql.gz | sudo -u postgres psql erp_db

# تشغيل التطبيق
systemctl start erp
```

---

## ✅ **النشر مكتمل!**

إذا أكملت جميع النقاط أعلاه، فإن نظام ERP الخاص بك:
- ✅ يعمل على الإنتاج
- ✅ آمن ومحمي
- ✅ لديه نسخ احتياطية تلقائية
- ✅ لديه مراقبة صحية تلقائية
- ✅ جاهز للاستخدام!

**🎉 مبروك!**

