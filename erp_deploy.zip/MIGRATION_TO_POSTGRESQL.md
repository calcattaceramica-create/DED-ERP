# دليل تحويل التطبيق من SQLite إلى PostgreSQL

## 📋 الخطوات المطلوبة

### 1️⃣ تثبيت PostgreSQL

#### على Windows:
1. قم بتحميل PostgreSQL من الموقع الرسمي:
   - https://www.postgresql.org/download/windows/
   - أو استخدم: https://www.enterprisedb.com/downloads/postgres-postgresql-downloads

2. قم بتثبيت PostgreSQL:
   - اختر كلمة مرور قوية للمستخدم `postgres`
   - احفظ كلمة المرور في مكان آمن
   - المنفذ الافتراضي: `5432`

3. تأكد من تشغيل خدمة PostgreSQL:
   - افتح Services (خدمات Windows)
   - ابحث عن `postgresql-x64-XX`
   - تأكد أنها تعمل (Running)

---

### 2️⃣ تثبيت مكتبة psycopg2

قم بتشغيل الأمر التالي في Terminal:

```bash
pip install psycopg2-binary
```

أو إذا واجهت مشاكل:

```bash
pip install psycopg2
```

---

### 3️⃣ إنشاء قاعدة بيانات PostgreSQL

افتح **pgAdmin** أو **SQL Shell (psql)** وقم بتنفيذ:

```sql
-- إنشاء قاعدة بيانات جديدة
CREATE DATABASE ded_erp;

-- إنشاء مستخدم جديد (اختياري)
CREATE USER ded_user WITH PASSWORD 'your_strong_password_here';

-- منح الصلاحيات
GRANT ALL PRIVILEGES ON DATABASE ded_erp TO ded_user;
```

**ملاحظة:** استبدل `your_strong_password_here` بكلمة مرور قوية

---

### 4️⃣ إنشاء ملف .env

سيتم إنشاء ملف `.env` تلقائياً بالمعلومات التالية:

```env
# Database Configuration
DATABASE_URL=postgresql://ded_user:your_password@localhost:5432/ded_erp

# Application Configuration
SECRET_KEY=your-secret-key-here
FLASK_ENV=development
```

---

### 5️⃣ نقل البيانات من SQLite إلى PostgreSQL

سيتم استخدام سكريبت تلقائي لنقل جميع البيانات.

---

## ⚠️ تحذيرات مهمة

1. **النسخ الاحتياطي:**
   - سيتم إنشاء نسخة احتياطية من قاعدة SQLite الحالية تلقائياً
   - الملف: `erp_system.db.backup`

2. **التوقف المؤقت:**
   - يجب إيقاف التطبيق أثناء عملية النقل
   - لا تقم بأي عمليات أثناء النقل

3. **الوقت المتوقع:**
   - يعتمد على حجم البيانات
   - عادة: 5-15 دقيقة

---

## 🎯 الخطوات التالية

بعد إكمال الإعداد أعلاه، سأقوم بـ:

1. ✅ إنشاء ملف `.env` بالإعدادات الصحيحة
2. ✅ إنشاء سكريبت نقل البيانات
3. ✅ نقل جميع البيانات من SQLite إلى PostgreSQL
4. ✅ التحقق من صحة البيانات
5. ✅ تحديث التطبيق ليستخدم PostgreSQL

---

## 📞 هل أنت جاهز؟

قبل أن أبدأ، يرجى التأكد من:

- [ ] تم تثبيت PostgreSQL
- [ ] تم إنشاء قاعدة البيانات `ded_erp`
- [ ] تم إنشاء المستخدم `ded_user` (أو استخدام `postgres`)
- [ ] لديك كلمة المرور

**بعد التأكد، أخبرني بالمعلومات التالية:**

1. اسم المستخدم: (مثال: `ded_user` أو `postgres`)
2. كلمة المرور: (سيتم حفظها في ملف `.env` فقط)
3. اسم قاعدة البيانات: (مثال: `ded_erp`)
4. المنفذ: (الافتراضي: `5432`)

