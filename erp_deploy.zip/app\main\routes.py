from flask import render_template, redirect, url_for, flash, request, make_response, after_this_request
from flask_login import login_required, current_user
from app.auth.decorators import permission_required
from app.main import bp
from app import db
from app.models import *
from sqlalchemy import func
from datetime import datetime, timedelta
import calendar
import json
from pathlib import Path

@bp.after_request
def add_cache_headers(response):
    """Add cache-busting headers to all responses"""
    if not response.cache_control.no_cache:
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate, max-age=0'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
    return response

@bp.route('/')
@bp.route('/index')
@login_required
@permission_required('dashboard.view')
def index():
    """Dashboard - Main page"""

    # Get statistics
    stats = {
        'total_products': Product.query.filter_by(is_active=True).count(),
        'total_customers': Customer.query.filter_by(is_active=True).count(),
        'total_suppliers': Supplier.query.filter_by(is_active=True).count(),
        'low_stock_products': 0,
        'total_warehouses': Warehouse.query.filter_by(is_active=True).count(),
    }

    # Calculate low stock products
    products = Product.query.filter_by(is_active=True, track_inventory=True).all()
    for product in products:
        current_stock = product.get_stock()
        if product.min_stock and current_stock <= product.min_stock:
            stats['low_stock_products'] += 1

    # Get recent sales
    recent_sales = SalesInvoice.query.order_by(SalesInvoice.created_at.desc()).limit(5).all()

    # Get recent purchases
    recent_purchases = PurchaseInvoice.query.order_by(PurchaseInvoice.created_at.desc()).limit(5).all()

    # Sales this month
    today = datetime.utcnow()
    first_day = today.replace(day=1)
    sales_this_month = db.session.query(func.sum(SalesInvoice.total_amount)).filter(
        SalesInvoice.invoice_date >= first_day,
        SalesInvoice.status != 'cancelled'
    ).scalar() or 0

    # Purchases this month
    purchases_this_month = db.session.query(func.sum(PurchaseInvoice.total_amount)).filter(
        PurchaseInvoice.invoice_date >= first_day,
        PurchaseInvoice.status != 'cancelled'
    ).scalar() or 0

    # Calculate COGS (Cost of Goods Sold) this month
    sales_invoices = SalesInvoice.query.filter(
        SalesInvoice.invoice_date >= first_day,
        SalesInvoice.status != 'cancelled'
    ).all()

    cogs_this_month = 0
    for invoice in sales_invoices:
        for item in invoice.items:
            cogs_this_month += item.product.cost_price * item.quantity

    # Calculate profit this month (Sales - COGS)
    profit_this_month = sales_this_month - cogs_this_month

    stats['sales_this_month'] = sales_this_month
    stats['purchases_this_month'] = purchases_this_month
    stats['profit_this_month'] = profit_this_month

    # Get sales data for last 6 months
    sales_chart_data = []
    purchases_chart_data = []
    chart_labels = []

    for i in range(5, -1, -1):
        month_date = today - timedelta(days=30*i)
        month_start = month_date.replace(day=1)

        # Get last day of month
        last_day = calendar.monthrange(month_start.year, month_start.month)[1]
        month_end = month_start.replace(day=last_day)

        # Sales for this month
        month_sales = db.session.query(func.sum(SalesInvoice.total_amount)).filter(
            SalesInvoice.invoice_date >= month_start,
            SalesInvoice.invoice_date <= month_end,
            SalesInvoice.status != 'cancelled'
        ).scalar() or 0

        # Purchases for this month
        month_purchases = db.session.query(func.sum(PurchaseInvoice.total_amount)).filter(
            PurchaseInvoice.invoice_date >= month_start,
            PurchaseInvoice.invoice_date <= month_end,
            PurchaseInvoice.status != 'cancelled'
        ).scalar() or 0

        sales_chart_data.append(float(month_sales))
        purchases_chart_data.append(float(month_purchases))

        # Arabic month names
        arabic_months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
                        'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']
        chart_labels.append(arabic_months[month_start.month - 1])

    # Get top selling products
    top_products = db.session.query(
        Product.name,
        func.sum(SalesInvoiceItem.quantity).label('total_qty')
    ).join(SalesInvoiceItem).join(SalesInvoice).filter(
        SalesInvoice.status != 'cancelled',
        SalesInvoice.invoice_date >= first_day
    ).group_by(Product.id).order_by(func.sum(SalesInvoiceItem.quantity).desc()).limit(5).all()

    # Calculate inventory value
    inventory_value = 0
    for product in products:
        stock_qty = product.get_stock()
        inventory_value += stock_qty * product.cost_price

    stats['inventory_value'] = inventory_value

    # Get bank accounts data
    bank_accounts = BankAccount.query.filter_by(is_active=True).all()
    total_bank_balance = sum(acc.current_balance for acc in bank_accounts)
    stats['total_bank_balance'] = total_bank_balance
    stats['bank_accounts_count'] = len(bank_accounts)

    # Get recent bank transactions
    recent_bank_transactions = BankTransaction.query.order_by(BankTransaction.created_at.desc()).limit(5).all()

    # Get expenses this month
    expenses_this_month = db.session.query(func.sum(Expense.amount)).filter(
        Expense.expense_date >= first_day,
        Expense.status != 'cancelled'
    ).scalar() or 0
    stats['expenses_this_month'] = expenses_this_month

    return render_template('main/index.html',
                         stats=stats,
                         recent_sales=recent_sales,
                         recent_purchases=recent_purchases,
                         sales_chart_data=sales_chart_data,
                         purchases_chart_data=purchases_chart_data,
                         chart_labels=chart_labels,
                         top_products=top_products,
                         bank_accounts=bank_accounts,
                         recent_bank_transactions=recent_bank_transactions)

@bp.route('/about')
def about():
    return render_template('main/about.html')



