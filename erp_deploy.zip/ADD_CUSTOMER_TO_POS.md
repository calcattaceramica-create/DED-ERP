# إضافة خانة إضافة عميل جديد في نقطة البيع
# Add New Customer Feature to POS

## 🎯 المطلوب | Requirements

إضافة إمكانية إضافة عميل جديد مباشرة من شاشة نقطة البيع دون الحاجة للخروج من الشاشة.

---

## ✅ التغييرات المنجزة | Changes Made

### **1. إضافة زر "إضافة عميل" بجانب قائمة العملاء**

**الملف:** `app/templates/pos/index.html` - السطور 555-571

تم تحويل حقل اختيار العميل إلى `input-group` مع زر إضافة:

**ملاحظة:** تم ترجمة جميع النصوص إلى الإنجليزية

```html
<div class="input-group">
    <select class="form-select" id="customer-select">
        <option value="">{{ _('Walk-in Customer') }}</option>
        {% for customer in customers %}
        <option value="{{ customer.id }}">{{ customer.name }} - {{ customer.phone }}</option>
        {% endfor %}
    </select>
    <button class="btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#addCustomerModal" title="إضافة عميل جديد">
        <i class="fas fa-plus"></i>
    </button>
</div>
```

**المميزات:**
- ✅ زر أزرق بأيقونة `+` بجانب قائمة العملاء
- ✅ يفتح نافذة منبثقة (Modal) لإضافة عميل جديد
- ✅ تصميم متناسق مع واجهة نقطة البيع

---

### **2. إضافة نافذة منبثقة (Modal) لإضافة العميل**

**الملف:** `app/templates/pos/index.html` - السطور 1235-1339

تم إضافة Modal كامل يحتوي على نموذج إضافة عميل:

**الحقول المتوفرة:**
- ✅ **الاسم** (إجباري)
- ✅ **الاسم بالإنجليزية** (اختياري)
- ✅ **رقم الجوال** (إجباري)
- ✅ **رقم الهاتف** (اختياري)
- ✅ **البريد الإلكتروني** (اختياري)
- ✅ **نوع العميل** (فرد/شركة)
- ✅ **العنوان** (اختياري)
- ✅ **المدينة** (اختياري)
- ✅ **الدولة** (اختياري)
- ✅ **الرقم الضريبي** (اختياري)
- ✅ **الفئة** (VIP/عادي/جملة)

**التصميم:**
- ✅ رأس أزرق مع أيقونة
- ✅ نموذج منظم في صفين
- ✅ أزرار حفظ وإلغاء

---

### **3. إضافة دالة JavaScript لحفظ العميل**

**الملف:** `app/templates/pos/index.html` - السطور 1199-1233

تم إضافة دالة `addNewCustomer()` التي:

```javascript
async function addNewCustomer() {
    const form = document.getElementById('addCustomerForm');
    const formData = new FormData(form);
    
    // إرسال البيانات عبر AJAX
    const response = await fetch('/sales/customers/add_ajax', {
        method: 'POST',
        body: formData
    });
    
    const result = await response.json();
    
    if (result.success) {
        // إضافة العميل للقائمة المنسدلة
        const customerSelect = document.getElementById('customer-select');
        const option = document.createElement('option');
        option.value = result.customer.id;
        option.text = result.customer.name + ' - ' + formData.get('phone');
        option.selected = true;
        customerSelect.add(option);
        
        // إغلاق النافذة ومسح النموذج
        modal.hide();
        form.reset();
        
        alert('تم إضافة العميل بنجاح!');
    }
}
```

**المميزات:**
- ✅ إرسال البيانات عبر AJAX دون إعادة تحميل الصفحة
- ✅ إضافة العميل الجديد تلقائياً للقائمة المنسدلة
- ✅ اختيار العميل الجديد تلقائياً
- ✅ إغلاق النافذة ومسح النموذج بعد النجاح
- ✅ رسالة تأكيد للمستخدم

---

### **4. استخدام Route موجود مسبقاً**

**الملف:** `app/sales/routes.py` - السطور 74-118

تم استخدام route موجود مسبقاً `/sales/customers/add_ajax` الذي:
- ✅ يولد كود العميل تلقائياً
- ✅ يحفظ بيانات العميل في قاعدة البيانات
- ✅ يرجع JSON مع معلومات العميل الجديد

---

## 🎯 كيفية الاستخدام | How to Use

### **الخطوات:**

1. **افتح نقطة البيع:**
   ```
   اذهب إلى: نقطة البيع
   ```

2. **اضغط على زر "+" بجانب قائمة العملاء:**
   - ستظهر نافذة منبثقة لإضافة عميل جديد

3. **املأ بيانات العميل:**
   - الاسم (إجباري)
   - رقم الجوال (إجباري)
   - باقي الحقول اختيارية

4. **اضغط "حفظ العميل":**
   - ✅ سيتم حفظ العميل في قاعدة البيانات
   - ✅ سيظهر العميل في القائمة المنسدلة
   - ✅ سيتم اختيار العميل تلقائياً
   - ✅ ستغلق النافذة المنبثقة

5. **أكمل عملية البيع:**
   - العميل الجديد الآن محدد في الطلب
   - يمكنك إضافة المنتجات وإتمام البيع

---

## 📊 ملخص الملفات المعدلة | Modified Files

| الملف | التغيير | السطور |
|-------|---------|--------|
| **app/templates/pos/index.html** | إضافة زر + بجانب قائمة العملاء | 555-571 |
| **app/templates/pos/index.html** | إضافة دالة JavaScript | 1199-1233 |
| **app/templates/pos/index.html** | إضافة Modal نموذج العميل | 1235-1339 |
| **app/sales/routes.py** | استخدام route موجود | 74-118 |

---

## 🔒 الصلاحيات المطلوبة | Required Permissions

لإضافة عميل جديد، يجب أن يكون لدى المستخدم الصلاحية:
```
customers.create
```

---

## ✨ المميزات | Features

- ✅ **سريع:** إضافة عميل دون مغادرة شاشة نقطة البيع
- ✅ **سهل:** نموذج بسيط وواضح
- ✅ **تلقائي:** العميل يضاف للقائمة ويُختار تلقائياً
- ✅ **آمن:** يستخدم AJAX مع التحقق من الصلاحيات
- ✅ **متناسق:** تصميم يتماشى مع واجهة نقطة البيع

---

**تاريخ الإضافة:** 2026-02-14
**الحالة:** ✅ تم بنجاح

