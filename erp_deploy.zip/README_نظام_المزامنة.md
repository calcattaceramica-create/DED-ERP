# 🔄 نظام المزامنة الثنائية للتراخيص
## Bidirectional License Synchronization System

---

## 📋 نظرة عامة - Overview

نظام متكامل للمزامنة الثنائية بين **لوحة التحكم (Control Panel)** و**قاعدة البيانات الرئيسية (licenses_master.db)**، يتيح التحكم الكامل في التراخيص من داخل وخارج التطبيق.

A complete bidirectional synchronization system between **Control Panel** and **Main Database (licenses_master.db)**, allowing full license control from inside and outside the application.

---

## ✨ المميزات - Features

### 1️⃣ المزامنة التلقائية - Auto-Sync
- ⏱️ مزامنة تلقائية كل 30 ثانية
- 🔄 تحديث واجهة المستخدم تلقائياً
- 📊 عرض التغييرات فوراً

### 2️⃣ المزامنة اليدوية - Manual Sync
- 🔘 زر "🔄 مزامنة" في الواجهة
- ⚡ مزامنة فورية بضغطة واحدة
- ✅ رسائل تأكيد واضحة

### 3️⃣ التحكم الخارجي - External Control
- 🔧 استخدام `license_control.py`
- 📝 سكريبتات Python مخصصة
- 🌐 API محتمل للمستقبل

### 4️⃣ التحكم من Control Panel
- ➕ إضافة تراخيص جديدة
- ✅ تفعيل/إيقاف التراخيص
- 🔄 تمديد التراخيص
- ✏️ تعديل بيانات التراخيص

---

## 🚀 البدء السريع - Quick Start

### الطريقة 1: استخدام Control Panel

```bash
# 1. افتح Control Panel
cd C:\Users\DELL\Desktop\DED_Portable_App
python DED_Control_Panel.pyw

# 2. انتقل إلى تبويب "مدير التراخيص"
# 3. استخدم الأزرار للتحكم في التراخيص
# 4. اضغط "🔄 مزامنة" للمزامنة الفورية
```

### الطريقة 2: التحكم الخارجي

```python
# في سكريبت Python
import sys
sys.path.insert(0, 'C:/Users/DELL/Desktop/DED_Portable_App')

from license_control import LicenseControl
lc = LicenseControl()

# إيقاف ترخيص
success, msg = lc.suspend_license("XXXX-XXXX-XXXX-XXXX", "سبب الإيقاف")
print(msg)

# تفعيل ترخيص
success, msg = lc.activate_license("XXXX-XXXX-XXXX-XXXX")
print(msg)

# تمديد ترخيص
success, msg = lc.extend_license("XXXX-XXXX-XXXX-XXXX", days=60)
print(msg)
```

---

## 📊 كيف يعمل النظام - How It Works

```
┌─────────────────────────────────────────────────────────────┐
│                  نظام المزامنة الثنائية                    │
└─────────────────────────────────────────────────────────────┘

1️⃣ External Control → Database (فوري - Immediate)
   license_control.py ──► licenses_master.db

2️⃣ Database → Control Panel (كل 30 ثانية - Every 30s)
   licenses_master.db ──► sync_from_database() ──► licenses.json

3️⃣ Control Panel → Database (فوري - Immediate)
   Control Panel GUI ──► licenses.json + licenses_master.db

4️⃣ Manual Sync (فوري - Immediate)
   زر "🔄 مزامنة" ──► manual_sync() ──► تحديث فوري
```

---

## 📁 الملفات الرئيسية - Main Files

| الملف | الوصف |
|------|-------|
| `DED_Control_Panel.pyw` | لوحة التحكم الرئيسية |
| `license_control.py` | وحدة التحكم الخارجي |
| `licenses_master.db` | قاعدة البيانات الرئيسية |
| `licenses.json` | ملف التخزين المحلي |
| `tenant_*.db` | قواعد بيانات المستأجرين |

---

## 🧪 الاختبار - Testing

```bash
# اختبار نظام المزامنة
python test_sync_system.py

# مثال على التحكم الخارجي
python example_external_license_control.py

# اختبار إنشاء التراخيص
python test_control_panel_license_creation.py
```

---

## 📝 الوظائف المتاحة - Available Functions

### في `license_control.py`:

| الوظيفة | الوصف |
|---------|-------|
| `get_all_licenses()` | الحصول على جميع التراخيص |
| `activate_license(key)` | تفعيل ترخيص |
| `suspend_license(key, reason)` | إيقاف ترخيص |
| `deactivate_license(key)` | إلغاء تفعيل ترخيص |
| `extend_license(key, days)` | تمديد ترخيص |

### في `DED_Control_Panel.pyw`:

| الوظيفة | الوصف |
|---------|-------|
| `sync_from_database()` | مزامنة من قاعدة البيانات |
| `auto_sync()` | مزامنة تلقائية |
| `manual_sync()` | مزامنة يدوية |
| `add_license_to_master_db()` | إضافة ترخيص للقاعدة |
| `create_tenant_database()` | إنشاء قاعدة بيانات مستأجر |

---

## ⚙️ الإعدادات - Settings

### تغيير وقت المزامنة التلقائية:

في `DED_Control_Panel.pyw`، السطر 93:

```python
# الإعداد الحالي: 30 ثانية
self.auto_sync_interval = 30000  # milliseconds

# للتغيير إلى 10 ثوانٍ:
self.auto_sync_interval = 10000

# للتغيير إلى دقيقة واحدة:
self.auto_sync_interval = 60000
```

---

## 🎯 حالات الاستخدام - Use Cases

### 1. إدارة مركزية للتراخيص
- إدارة جميع التراخيص من لوحة تحكم واحدة
- مزامنة تلقائية مع قاعدة البيانات
- تحديثات فورية

### 2. التحكم الآلي
- سكريبتات Python للتحكم التلقائي
- جدولة العمليات (Cron Jobs)
- تكامل مع أنظمة أخرى

### 3. المراقبة والتقارير
- مراقبة حالة التراخيص
- تقارير دورية
- تنبيهات تلقائية

---

## 📞 الدعم - Support

للمساعدة أو الاستفسارات:
- 📧 البريد الإلكتروني: support@ded-erp.com
- 📱 الهاتف: +XXX-XXX-XXXX
- 🌐 الموقع: www.ded-erp.com

---

## 📄 الترخيص - License

© 2026 DED ERP System. All rights reserved.

---

**🎉 نظام المزامنة جاهز للاستخدام! - Sync System Ready to Use!**

