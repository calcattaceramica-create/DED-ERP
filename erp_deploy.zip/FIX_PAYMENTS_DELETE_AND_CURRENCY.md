# ربط المدفوعات والمقبوضات بالحساب البنكي
# Link Payments/Receipts to Bank Account

## 🎯 المطلوب | Requirements

1. ✅ ربط المدفوعات والمقبوضات بالحساب البنكي
2. ✅ عند عمل مدفوعات: ينقص من رصيد البنك
3. ✅ عند عمل مقبوضات: يزيد رصيد البنك
4. ✅ عند حذف مدفوعات: يزيد رصيد البنك (عكس)
5. ✅ عند حذف مقبوضات: ينقص من رصيد البنك (عكس)
6. ✅ تفعيل زر الحذف في صفحة المدفوعات
7. ✅ تغيير العملة من "ريال" إلى "€" (يورو)

---

## ✅ التغييرات المنجزة | Changes Made

### **1. ربط المدفوعات بالحساب البنكي عند الإنشاء**

**الملف:** `app/accounting/routes.py` - السطور 328-357

تم إضافة كود لتحديث رصيد البنك عند إنشاء مدفوعة/مقبوضة:

```python
# Update bank account balance if bank payment method
if payment.bank_account_id and payment.payment_method in ['bank', 'check', 'card']:
    try:
        # Determine transaction type based on payment type
        if payment.payment_type == 'receipt':
            # Receipt: deposit money into bank (increase balance)
            transaction_type = 'deposit'
            description = f'مقبوضات - {payment.payment_number}'
        else:
            # Payment: withdraw money from bank (decrease balance)
            transaction_type = 'withdrawal'
            description = f'مدفوعات - {payment.payment_number}'

        # Create bank transaction
        bank_transaction = create_bank_transaction(
            bank_account_id=payment.bank_account_id,
            transaction_type=transaction_type,
            amount=payment.amount,
            reference_type='payment',
            reference_id=payment.id,
            description=description
        )
```

**آلية العمل:**

**للمقبوضات (Receipt):**
```python
# نوع المعاملة: deposit (إيداع)
# رصيد البنك = رصيد البنك + المبلغ
transaction_type = 'deposit'
```

**للمدفوعات (Payment):**
```python
# نوع المعاملة: withdrawal (سحب)
# رصيد البنك = رصيد البنك - المبلغ
transaction_type = 'withdrawal'
```

---

### **2. عكس المعاملة البنكية عند الحذف**

**الملف:** `app/accounting/routes.py` - السطور 411-449

تم إضافة route لحذف المدفوعات مع عكس المعاملة البنكية:

```python
@bp.route('/payments/<int:id>/delete', methods=['POST'])
@login_required
@permission_required('accounting.payments.delete')
def delete_payment(id):
    """Delete payment - حذف مدفوعة"""
```

**آلية عكس المعاملة:**

**للمقبوضات (Receipt):**
```python
# عند الإنشاء: رصيد البنك + المبلغ
# عند الحذف: رصيد البنك - المبلغ (عكس)
if payment.payment_type == 'receipt':
    bank_account.current_balance -= payment.amount
```

**للمدفوعات (Payment):**
```python
# عند الإنشاء: رصيد البنك - المبلغ
# عند الحذف: رصيد البنك + المبلغ (عكس)
else:
    bank_account.current_balance += payment.amount
```

---

### **2. إضافة زر الحذف في صفحة القائمة**

**الملف:** `app/templates/accounting/payments.html` - السطور 101-110

تم إضافة زر حذف أحمر بجانب زر التفاصيل:

```html
<button onclick="deletePayment({{ payment.id }}, '{{ payment.payment_number }}')" 
        class="btn btn-sm btn-danger" title="حذف">
    <i class="fas fa-trash"></i>
</button>
```

---

### **3. إضافة JavaScript للتأكيد**

**الملف:** `app/templates/accounting/payments.html` - السطور 161-175

تم إضافة دالة JavaScript لتأكيد الحذف:

```javascript
function deletePayment(paymentId, paymentNumber) {
    if (confirm(`هل أنت متأكد من حذف المدفوعة ${paymentNumber}؟\n\nملاحظة: سيتم عكس المعاملة البنكية إذا كانت موجودة.`)) {
        // Create form and submit
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = `/accounting/payments/${paymentId}/delete`;
        document.body.appendChild(form);
        form.submit();
    }
}
```

---

### **4. تغيير العملة إلى اليورو**

#### **أ. صفحة قائمة المدفوعات**
**الملف:** `app/templates/accounting/payments.html` - السطر 78

```html
<!-- قبل -->
{{ "{:,.2f}".format(payment.amount) }} ريال

<!-- بعد -->
{{ "{:,.2f}".format(payment.amount) }} €
```

#### **ب. صفحة تفاصيل المدفوعة**
**الملف:** `app/templates/accounting/payment_details.html` - السطر 40

```html
<!-- قبل -->
{{ "{:,.2f}".format(payment.amount) }} ريال

<!-- بعد -->
{{ "{:,.2f}".format(payment.amount) }} €
```

---

## 📋 ملخص الملفات المعدلة | Modified Files

| الملف | التغيير | السطور |
|-------|---------|--------|
| **app/accounting/routes.py** | إضافة route حذف المدفوعة | 378-417 |
| **app/templates/accounting/payments.html** | زر الحذف + JavaScript | 101-110, 161-175 |
| **app/templates/accounting/payments.html** | تغيير العملة | 78 |
| **app/templates/accounting/payment_details.html** | تغيير العملة | 40 |

---

## 🧪 كيفية الاختبار | How to Test

### **اختبار الحذف:**

**1. افتح صفحة المدفوعات:**
```
اذهب إلى: المحاسبة > المدفوعات والمقبوضات
```

**2. اختبر حذف مقبوضة بنكية:**
- أنشئ مقبوضة بنكية بمبلغ 500€
- تحقق من رصيد البنك (يجب أن يزيد 500€)
- اضغط على زر الحذف 🗑️ الأحمر
- أكد الحذف
- **النتيجة المتوقعة:**
  - ✅ تم حذف المقبوضة
  - ✅ رصيد البنك نقص 500€ (عكس)
  - ✅ رسالة نجاح

**3. اختبر حذف مدفوعة بنكية:**
- أنشئ مدفوعة بنكية بمبلغ 300€
- تحقق من رصيد البنك (يجب أن ينقص 300€)
- اضغط على زر الحذف 🗑️
- أكد الحذف
- **النتيجة المتوقعة:**
  - ✅ تم حذف المدفوعة
  - ✅ رصيد البنك زاد 300€ (عكس)
  - ✅ رسالة نجاح

---

### **اختبار العملة:**

**1. افتح صفحة المدفوعات:**
- يجب أن تظهر جميع المبالغ بـ `€` بدلاً من `ريال` ✅

**2. افتح تفاصيل أي مدفوعة:**
- يجب أن يظهر المبلغ بـ `€` بدلاً من `ريال` ✅

---

## 📊 جدول المقارنة | Comparison Table

| العنصر | قبل | بعد |
|--------|-----|-----|
| **زر الحذف** | ❌ غير موجود | ✅ موجود |
| **حذف المدفوعة** | ❌ لا يعمل | ✅ يعمل |
| **عكس المعاملة البنكية** | ❌ لا يعمل | ✅ يعمل |
| **تأكيد الحذف** | ❌ لا يوجد | ✅ يوجد |
| **العملة في القائمة** | ريال | € |
| **العملة في التفاصيل** | ريال | € |

---

## 🔒 الصلاحيات المطلوبة | Required Permissions

لحذف المدفوعات، يجب أن يكون لدى المستخدم الصلاحية:
```
accounting.payments.delete
```

---

**تاريخ الإصلاح:** 2026-02-13
**الحالة:** ✅ تم الإصلاح بنجاح

