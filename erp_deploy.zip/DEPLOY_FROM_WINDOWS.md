# 🚀 دليل النشر من Windows إلى Linux Server

---

## 📋 **الطريقة الموصى بها: النشر المباشر**

---

## ✅ **الخطوة 1: رفع الملفات للسيرفر**

### **استخدام WinSCP أو FileZilla:**

1. **حمّل WinSCP** من: https://winscp.net/
2. **اتصل بالسيرفر:**
   - Host: `147.79.102.91`
   - Username: `root`
   - Password: كلمة مرور السيرفر
   - Port: `22`

3. **ارفع هذه الملفات:**
   ```
   - المجلد الكامل (DED) → /root/erp
   - deploy_erp_improved.sh → /root/
   - .env.production → /root/erp/
   ```

---

## ✅ **الخطوة 2: الاتصال بالسيرفر عبر SSH**

### **استخدام PuTTY:**

1. **حمّل PuTTY** من: https://www.putty.org/
2. **اتصل بالسيرفر:**
   - Host Name: `147.79.102.91`
   - Port: `22`
   - Connection Type: SSH
3. **سجّل الدخول:**
   - Username: `root`
   - Password: كلمة مرور السيرفر

---

## ✅ **الخطوة 3: تشغيل السكريبت على السيرفر**

بعد الاتصال بالسيرفر عبر SSH، نفّذ هذه الأوامر:

```bash
# الانتقال للمجلد الرئيسي
cd /root

# جعل السكريبت قابل للتنفيذ
chmod +x deploy_erp_improved.sh

# تشغيل السكريبت
./deploy_erp_improved.sh
```

---

## 🎯 **الطريقة البديلة: استخدام PowerShell مع SSH**

إذا كان لديك OpenSSH على Windows:

```powershell
# 1. رفع الملفات
scp -r C:\Users\DELL\DED root@147.79.102.91:/root/erp
scp C:\Users\DELL\DED\deploy_erp_improved.sh root@147.79.102.91:/root/

# 2. الاتصال بالسيرفر
ssh root@147.79.102.91

# 3. على السيرفر، نفّذ:
cd /root
chmod +x deploy_erp_improved.sh
./deploy_erp_improved.sh
```

---

## 📦 **الطريقة الأسهل: ضغط ورفع**

### **على Windows:**

```powershell
# ضغط المشروع
Compress-Archive -Path "C:\Users\DELL\DED\*" -DestinationPath "C:\Users\DELL\DED\erp.zip" -Force
```

### **رفع erp.zip للسيرفر باستخدام WinSCP**

### **على السيرفر (عبر SSH):**

```bash
# فك الضغط
cd /root
unzip erp.zip -d erp

# جعل السكريبت قابل للتنفيذ
chmod +x deploy_erp_improved.sh

# تشغيل السكريبت
./deploy_erp_improved.sh
```

---

## 🔧 **الأدوات المطلوبة:**

### **للرفع:**
- ✅ **WinSCP** (مجاني): https://winscp.net/
- أو **FileZilla** (مجاني): https://filezilla-project.org/

### **للاتصال بالسيرفر:**
- ✅ **PuTTY** (مجاني): https://www.putty.org/
- أو **Windows Terminal** مع OpenSSH

---

## 📝 **معلومات الاتصال:**

```
Server IP: 147.79.102.91
Server Host: srv1392516.hstgr.cloud
Username: root
Port: 22
```

---

## ⚡ **الخطوات السريعة (ملخص):**

1. **حمّل WinSCP و PuTTY**
2. **ارفع المشروع للسيرفر** باستخدام WinSCP
3. **اتصل بالسيرفر** باستخدام PuTTY
4. **نفّذ السكريبت:**
   ```bash
   cd /root
   chmod +x deploy_erp_improved.sh
   ./deploy_erp_improved.sh
   ```

---

## 🎊 **بعد النشر:**

زيارة: `https://srv1392516.hstgr.cloud`

تسجيل الدخول:
- Username: `admin`
- Password: `admin123`

---

## 🆘 **إذا واجهت مشاكل:**

### **مشكلة: لا يمكن الاتصال بالسيرفر**
```bash
# تحقق من أن SSH يعمل
ping 147.79.102.91
```

### **مشكلة: Permission denied**
```bash
# تأكد من أنك مسجل دخول كـ root
whoami
```

### **مشكلة: السكريبت لا يعمل**
```bash
# تحقق من الصلاحيات
ls -la deploy_erp_improved.sh

# أعد تعيين الصلاحيات
chmod +x deploy_erp_improved.sh
```

---

## 📞 **الدعم:**

راجع الملفات:
- `DEPLOYMENT_GUIDE.md` - دليل شامل
- `DEPLOYMENT_CHECKLIST.md` - قائمة تحقق
- `DEPLOYMENT_SUMMARY.md` - ملخص سريع

---

**🚀 حظاً موفقاً في النشر!**

