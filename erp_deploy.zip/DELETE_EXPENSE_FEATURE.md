# ✅ ميزة حذف المصروفات - Delete Expense Feature

## 📋 التغييرات التي تم إجراؤها

### 1. ✅ إضافة Route للحذف
**الملف:** `app/accounting/expenses_routes.py`

```python
@bp.route('/expenses/<int:id>/delete', methods=['POST', 'GET'])
@login_required
@permission_required('accounting.expenses.delete')
def delete_expense(id):
    """Delete expense - حذف المصروف"""
    try:
        expense = Expense.query.get_or_404(id)

        # Check if expense is posted
        if expense.status == 'posted':
            # If paid by bank, reverse the bank transaction
            if expense.payment_method == 'bank' and expense.bank_account_id:
                bank_account = BankAccount.query.get(expense.bank_account_id)
                if bank_account:
                    # Add back to bank balance
                    bank_account.current_balance += expense.amount

                    # Delete related bank transaction
                    BankTransaction.query.filter_by(
                        reference_type='expense',
                        reference_id=expense.id
                    ).delete()

        # Delete the expense
        db.session.delete(expense)
        db.session.commit()

        flash('تم حذف المصروف بنجاح', 'success')
        return redirect(url_for('accounting.expenses'))

    except Exception as e:
        db.session.rollback()
        flash(f'حدث خطأ أثناء حذف المصروف: {str(e)}', 'danger')
        return redirect(url_for('accounting.expense_details', id=id))
```

**المميزات:**
- ✅ يحذف المصروف من قاعدة البيانات
- ✅ إذا كان المصروف مدفوع بنكياً، يرجع المبلغ للحساب البنكي
- ✅ يحذف المعاملة البنكية المرتبطة
- ✅ يتحقق من الصلاحيات قبل الحذف

---

### 2. ✅ إضافة زر الحذف في الواجهة
**الملف:** `app/templates/accounting/expenses.html`

```html
<button type="button" class="btn btn-sm btn-danger"
        onclick="confirmDelete({{ expense.id }}, '{{ expense.expense_number }}')"
        title="حذف">
    <i class="fas fa-trash"></i>
</button>
```

**المميزات:**
- ✅ زر أحمر مع أيقونة سلة المهملات
- ✅ يظهر بجانب زر العرض
- ✅ يطلب تأكيد قبل الحذف

---

### 3. ✅ إضافة JavaScript للتأكيد
**الملف:** `app/templates/accounting/expenses.html`

```javascript
function confirmDelete(expenseId, expenseNumber) {
    if (confirm('هل أنت متأكد من حذف المصروف ' + expenseNumber + '؟\n\nملاحظة: إذا كان المصروف مدفوعاً بنكياً، سيتم إرجاع المبلغ للحساب البنكي.')) {
        window.location.href = '/accounting/expenses/' + expenseId + '/delete';
    }
}
```

**المميزات:**
- ✅ رسالة تأكيد بالعربية
- ✅ تنبيه المستخدم بأن المبلغ سيرجع للبنك إذا كان مدفوع بنكياً
- ✅ بسيط وسهل الاستخدام

---

### 4. ✅ إضافة الصلاحيات
**الصلاحيات المضافة:**
- `accounting.expenses.delete` - حذف المصروفات
- `accounting.expenses.create` - إضافة المصروفات

**تم ربطها بدور admin تلقائياً**

---

### 5. ✅ تغيير العملة إلى يورو
**الملف:** `app/models.py`

```python
currency = db.Column(db.String(3), default='EUR')  # Changed from SAR to EUR
```

**الملف:** `app/templates/accounting/expenses.html`
- تم استبدال "ريال" بـ `{{ currency_symbol }}`
- سيظهر € بدلاً من ريال

---

## 🚀 كيفية الاستخدام

### 1. إعادة تشغيل التطبيق
```bash
# طريقة 1: استخدام ملف restart_app.bat
double-click restart_app.bat

# طريقة 2: يدوياً
python run.py
```

### 2. تسجيل الدخول
- اسم المستخدم: `admin`
- كلمة المرور: `admin123`

### 3. الذهاب إلى صفحة المصروفات
```
http://localhost:5000/accounting/expenses
```

### 4. حذف مصروف
1. اضغط على الزر الأحمر (🗑️) بجانب المصروف
2. سيظهر تأكيد: "هل أنت متأكد من حذف المصروف؟"
3. اضغط OK للحذف أو Cancel للإلغاء
4. إذا كان المصروف مدفوع بنكياً، سيتم إرجاع المبلغ للحساب البنكي تلقائياً

---

## ✅ الاختبار

### اختبار 1: حذف مصروف نقدي
1. أنشئ مصروف نقدي
2. احذفه
3. تحقق من أنه تم حذفه من القائمة

### اختبار 2: حذف مصروف بنكي
1. أنشئ مصروف بنكي (مثلاً 800 يورو)
2. تحقق من رصيد البنك قبل الحذف
3. احذف المصروف
4. تحقق من أن رصيد البنك زاد بمقدار 800 يورو

### اختبار 3: الصلاحيات
1. سجل دخول بمستخدم ليس لديه صلاحية `accounting.expenses.delete`
2. حاول الوصول إلى `/accounting/expenses/1/delete`
3. يجب أن يظهر خطأ "Access Denied"

---

## 📝 ملاحظات

- ✅ الحذف نهائي ولا يمكن التراجع عنه
- ✅ إذا كان المصروف مدفوع بنكياً، يتم إرجاع المبلغ تلقائياً
- ✅ يتم حذف المعاملة البنكية المرتبطة
- ✅ يتطلب صلاحية `accounting.expenses.delete`
- ✅ المستخدم admin لديه الصلاحية افتراضياً

---

## 🎯 الخلاصة

تم إضافة ميزة حذف المصروفات بنجاح مع:
- ✅ زر حذف أحمر في قائمة المصروفات
- ✅ رسالة تأكيد قبل الحذف
- ✅ إرجاع المبلغ للبنك إذا كان مدفوع بنكياً
- ✅ نظام صلاحيات محكم
- ✅ تغيير العملة إلى يورو (€)

**جاهز للاستخدام! 🚀**

