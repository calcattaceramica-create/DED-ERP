# 🚀 خطوات نشر نظام DED ERP على Render

## ✅ تم إنجازه بنجاح!

### المراحل المكتملة:
- ✅ تثبيت Git
- ✅ إنشاء Git Repository
- ✅ رفع المشروع على GitHub
- ✅ **رابط المشروع:** https://github.com/calcattaceramica-create/miniature-fiesta

---

## 🎯 الخطوات المتبقية (5 دقائق!)

### 1️⃣ إنشاء حساب Render ✅ جاهز
- الرابط مفتوح: https://dashboard.render.com/register
- سجل دخول بحساب GitHub: **calcattaceramica-create**

### 2️⃣ نشر التطبيق تلقائياً (Blueprint)

**الطريقة الأسهل - نقرة واحدة!**

1. في لوحة Render → **"New +"**
2. اختر **"Blueprint"**
3. اختر repository: **miniature-fiesta**
4. Render سيقرأ ملف `render.yaml` تلقائياً
5. اضغط **"Apply"**

✨ سيتم إنشاء:
- قاعدة بيانات PostgreSQL
- Web Service
- ربطهما تلقائياً

### 3️⃣ انتظر اكتمال النشر
- ⏱️ يستغرق 5-10 دقائق
- راقب في **"Events"**
- ✅ عند ظهور **"Live"** → جاهز!

### 4️⃣ تهيئة قاعدة البيانات
1. Web Service → **"Shell"**
2. نفذ:
```bash
python init_db.py
python seed_data.py
```

### 5️⃣ الوصول للتطبيق 🎉
**الرابط:** `https://ded-erp-system.onrender.com`

**تسجيل الدخول:**
- 👤 Username: `admin`
- 🔑 Password: `admin123`

⚠️ **غيّر كلمة المرور فوراً!**

---

## ✅ تم!

الرابط: `https://ded-erp-system.onrender.com`

**تسجيل الدخول:**
- Username: `admin`
- Password: `admin123`

⚠️ **مهم:** غيّر كلمة المرور بعد أول تسجيل دخول!

---

## 🔧 ملاحظات

- الخطة المجانية قد تكون بطيئة قليلاً
- التطبيق يتوقف بعد 15 دقيقة من عدم الاستخدام
- يعود للعمل تلقائياً عند أول زيارة

---

## 📞 مشاكل؟

راجع الملف الكامل: `DEPLOYMENT_GUIDE.md`


2:30	تهيئة قاعدة البيانات	⏳ قريباً